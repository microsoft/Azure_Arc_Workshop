# install Guest Configuration module and if not already present
Install-Module -Name GuestConfiguration -scope AllUsers -force
Install-Module -Name Az -scope AllUsers -force
Install-Module -Name PSDscResources -scope AllUsers -force
Install-Module -Name SecurityPolicyDsc -scope AllUsers -force
Install-Module -Name AuditPolicyDsc -scope AllUsers -force
Install-Module -Name PSDesiredStateConfiguration -scope AllUsers -force