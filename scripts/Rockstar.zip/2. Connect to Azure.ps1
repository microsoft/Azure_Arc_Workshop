# Connect using your own account
Connect-AzAccount -Tenant $env:spnTenantId -UseDeviceAuthentication

# Output You need to connect using a web browser
# WARNING: To sign in, use a web browser to open the page https://microsoft.com/devicelogin and enter the code sample dfkjdakfh to authenticate.
# Account                                 SubscriptionName TenantId                             Environment
# philbr@azure.onmicrosoft.com            Sub1             085e7c88-b5df-4b07-89c7-029asdfd2e46b AzureCloud
