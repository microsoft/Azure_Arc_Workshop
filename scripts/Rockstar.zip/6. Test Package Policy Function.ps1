#Test Guest Configuration Package Function
Get-GuestConfigurationPackageComplianceStatus .\AccountPolicy_config.zip -Verbose

#Test Guest Configuration Set Package Function
###Start-GuestConfigurationPackageRemediation .\AccountPolicy_config.zip -Verbose