# Create a package that will make compliance
$params =@{
    Name            = 'AccountPolicy_config'
    Configuration   = './AccountPolicy_config/localhost.mof'
    Type            = 'AuditandSet' 
    Force           = $true
}
New-GuestConfigurationPackage @params


## Output
## Name                 Path                                                                                               
## ----                 ----                                                                                               
## AccountPolicy_config C:\Rockstar\AccountPolicy_config.zip    