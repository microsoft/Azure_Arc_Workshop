# Create an Azure Policy definition
$bracher_guid = New-Guid

    $PolicyConfig       = @{
    PolicyId        = $bracher_guid
    ContentUri      = $contenturi
    DisplayName     = '(ArcBox) Account Login Policy Settings'
    Description     = '(ArcBox) Account Login Policy Settings'
    Path            = 'AccountPolicy_config/policies'
    Platform        = 'Windows'
    PolicyVersion   = '1.0.0'
    Mode            = 'ApplyAndAutoCorrect'

}
New-GuestConfigurationPolicy @PolicyConfig 