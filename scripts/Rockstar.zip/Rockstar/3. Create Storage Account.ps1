# Create Storage Account
$resourceGroupName = "ArcBox"
$location = $env:azureLocation
$context = Get-AzContext
$subscriptionId = $context.Subscription.Id
$AzStorageContainerName = "azurearcrockstar"
$storageaccountsuffix = -join ((97..122) | Get-Random -Count 5 | % {[char]$_})
New-AzStorageAccount -ResourceGroupName $resourceGroupName -Name "machineconfigstg$storageaccountsuffix" -SkuName 'Standard_LRS' -Location $Location -OutVariable storageaccount -EnableHttpsTrafficOnly $true -AllowBlobPublicAccess $false  | New-AzStorageContainer -Name $AzStorageContainerName -PublicAccess Off


##Storage Account Name: machineconfigstgtskvi

##Name                 PublicAccess         LastModified                   IsDeleted  VersionId
##----                 ------------         ------------                   ---------  ---------
##azurearcrockstar     Blob                 5/7/2025 7:28:51 PM +00:00
