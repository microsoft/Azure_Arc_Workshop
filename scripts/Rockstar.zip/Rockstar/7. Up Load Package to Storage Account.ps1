# Up load packages to storage account
$StorageAccount = Get-AzStorageAccount -ResourceGroupName $ResourceGroupName | Where-Object StorageAccountName -like "machineconfigstg*"
$Context = New-AzStorageContext -StorageAccountName $storageaccount.StorageAccountName 
Set-AzStorageBlobContent -Container $AzStorageContainerName -File  "AccountPolicy_config.zip" -Blob "AccountPolicy_config.zip"-Context $Context -Force
$uri = (Get-AzStorageAccount -ResourceGroupName $ResourceGroupName -Name $storageAccount.StorageAccountName).PrimaryEndpoints.Blob
$contenturi = $uri + "$AzStorageContainerName" + "/AccountPolicy_config.zip"

# Create Azure Policy Definition
## Output
## Name                 BlobType  Length          ContentType                    LastModified         AccessTier SnapshotTime                 IsDeleted  VersionId
## ----                 --------  ------          -----------                    ------------         ---------- ------------                 ---------  ---------
## AccountPolicy_confi… BlockBlob 156275          application/octet-stream       2025-05-07 19:50:23Z Hot                                     False

