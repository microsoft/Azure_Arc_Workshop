# Variables
$vnetName = "Arcbox-VNet"
$subnetName = "Arcbox-Subnet"
$privateEndpointName = "ArcRockstarStorePEP1"
# Get resources
$vnet = Get-AzVirtualNetwork -Name $vnetName -ResourceGroupName $resourceGroup
$subnet = Get-AzVirtualNetworkSubnetConfig -Name $subnetName -VirtualNetwork $vnet
# Create Private Endpoint
New-AzPrivateEndpoint -ResourceGroupName $resourceGroup -Name $privateEndpointName -Location $location -Subnet $subnet -PrivateLinkServiceConnection @(
@{
            Name = "StoragePrivateLink"
            PrivateLinkServiceId = $storageAccount.Id
            GroupIds = @("blob") # Use "file", "queue", or "table" for other services
        }
    )

Start-Sleep -Seconds 30

New-AzPrivateDnsZoneGroup -ResourceGroupName $resourceGroupName -PrivateEndpointName $privateEndpointName -Name privatelink_blob_core_windows_net `
 -PrivateDnsZoneConfig @(New-AzPrivateDnsZoneConfig -Name privatelink.blob.core.windows.net -PrivateDnsZoneId (Get-AzPrivateDnsZone -Name "privatelink.blob.core.windows.net" -ResourceGroupName $resourceGroupName).ResourceId

 )
 
