# Create Account Policies to MOF

$accountPolicies = @{
    Enforce_password_history = 24
    Maximum_Password_Age = 42
    Minimum_Password_Age = 1
    Minimum_Password_Length = 14
    Password_must_meet_complexity_requirements = 'Enabled'
    Store_passwords_using_reversible_encryption = 'Disabled'
    Account_lockout_threshold = 10
    Reset_account_lockout_counter_after = 15
    Account_lockout_duration = 15

}
configuration AccountPolicy_config 
{
    
    Import-DscResource -ModuleName 'SecurityPolicyDsc'

    node localhost 
    {   
        AccountPolicy 'Enforce_password_history'           
        {      
            Name = 'Enforce_password_history'   
            Enforce_password_history = $accountPolicies.Enforce_password_history
        }
        AccountPolicy 'Maximum_Password_Age'
        {
             Name = 'Maximum_Password_Age'
            Maximum_Password_Age = $accountPolicies.Maximum_Password_Age
        }
        AccountPolicy 'Minimum_Password_Length'
        {
           Name = 'Minimum_Password_Length'
           Minimum_Password_Length = $accountPolicies.Minimum_Password_Age
        }
         AccountPolicy 'Password_must_meet_complexity_requirements'
        {
            Name = 'Password_must_meet_complexity_requirements'
            Password_must_meet_complexity_requirements = $accountPolicies.Password_must_meet_complexity_requirements
        }
        AccountPolicy 'Store_passwords_using_reversible_encryption'
        {
            Name = 'Store_passwords_using_reversible_encryption'
            Store_passwords_using_reversible_encryption = $accountPolicies.Store_passwords_using_reversible_encryption
        }
        AccountPolicy 'Account_lockout_threshold'
        {
            Name = 'Account_lockout_threshold'
            Account_lockout_threshold = $accountPolicies.Account_lockout_threshold
        }
        AccountPolicy  'Reset_account_lockout_counter_after'
        {
            Name = 'Reset_account_lockout_counter_after'
            Reset_account_lockout_counter_after = $accountPolicies.Reset_account_lockout_counter_after
        }
        AccountPolicy 'Account_lockout_duration'
        {
            Name = 'Account_lockout_duration'
            Account_lockout_duration = $accountPolicies.Account_lockout_duration
        }
        
    }
}
AccountPolicy_Config

#  Output
#  Directory: C:\Rockstar\AccountPolicy_config

##Mode                 LastWriteTime         Length Name
##---                 -------------         ------ ----
##-a---            5/7/2025  7:39 PM           3567 localhost.mof