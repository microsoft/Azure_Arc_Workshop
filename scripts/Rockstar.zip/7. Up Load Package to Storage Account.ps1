$StorageAccount = Get-AzStorageAccount -ResourceGroupName $ResourceGroupName | Where-Object StorageAccountName -like "machineconfigstglrmf*"
$StorageAccountKey = Get-AzStorageAccountKey -Name $storageaccount.StorageAccountName -ResourceGroupName $storageaccount.ResourceGroupName
$Context = New-AzStorageContext -StorageAccountName $storageaccount.StorageAccountName -StorageAccountKey $StorageAccountKey[0].Value
Set-AzStorageBlobContent -Container $AzStorageContainerName -File  "AccountPolicy_config.zip" -Blob "AccountPolicy_config.zip" -Context $Context -Force
$contenturi = New-AzStorageBlobSASToken -Context $Context -FullUri -Container $AzStorageContainerName -Blob "AccountPolicy_config.zip" -Permission r

## Output
## Name                 BlobType  Length          ContentType                    LastModified         AccessTier SnapshotTime                 IsDeleted  VersionId
## ----                 --------  ------          -----------                    ------------         ---------- ------------                 ---------  ---------
## AccountPolicy_confi… BlockBlob 156275          application/octet-stream       2025-05-07 19:50:23Z Hot                                     False
