$StorageAccount = Get-AzStorageAccount -ResourceGroupName $ResourceGroupName | Where-Object StorageAccountName -like "arcbox*"
Set-AzStorageAccount -ResourceGroupName $resourceGroupName -Name $StorageAccount.StorageAccountName  -SasExpirationPeriod 1.0:0:0

$StorageAccountKey = Get-AzStorageAccountKey -Name $StorageAccount.StorageAccountName -ResourceGroupName $StorageAccount.ResourceGroupName
$Context = New-AzStorageContext -StorageAccountName $StorageAccount.StorageAccountName -StorageAccountKey $StorageAccountKey[0].Value
New-AzStorageContainer -Name machineconfiguration -Permission Blob -Context $Context