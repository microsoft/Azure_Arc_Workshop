Install-PSResource -Name Az.Accounts -Version 4.1.0 -TrustRepository -Quiet
Install-PSResource -Name Az.PolicyInsights -Version 1.7.1 -TrustRepository
Install-PSResource -Name Az.Resources -Version 7.10.0 -TrustRepository
Install-PSResource -Name Az.Storage -Version 8.3.0 -TrustRepository
Install-PSResource -Name MSI -Version 3.3.4 -TrustRepository
Install-PSResource -Name GuestConfiguration -Version 4.7.0 -TrustRepository
Install-PSResource -Name PSDesiredStateConfiguration -Version 2.0.7 -TrustRepository
Install-PSResource -Name PSDscResources -Version 2.12.0.0 -TrustRepository

Import-Module -Name Az.Resources -RequiredVersion 7.10.0
Import-Module -Name PSDesiredStateConfiguration -Force -RequiredVersion 2.0.7
Get-Module