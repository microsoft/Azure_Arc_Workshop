  $PolicyAssignment = Get-AzPolicyAssignment -PolicyDefinitionId $PolicyDefinition.Id | Where-Object Name -eq '(AzureArcJumpstart) [Windows] Custom configuration'

  $roleDefinitionIds =  $PolicyDefinition.policyRule.then.details.roleDefinitionIds

  # Wait for eventual consistency
  Start-Sleep 20
  # Assign necessary roles
  if ($roleDefinitionIds.Count -gt 0)
   {
       $roleDefinitionIds | ForEach-Object {
           $roleDefId = $_.Split("/") | Select-Object -Last 1
           New-AzRoleAssignment -Scope $resourceGroup.ResourceId -ObjectId $PolicyAssignment.IdentityPrincipalId -RoleDefinitionId $roleDefId
       }
   }
  # Start remediation job
   $job = Start-AzPolicyRemediation -AsJob -Name ($PolicyAssignment.Id -split '/')[-1] -PolicyAssignmentId $PolicyAssignment.Id -ResourceGroupName $ResourceGroup.ResourceGroupName -ResourceDiscoveryMode ReEvaluateCompliance