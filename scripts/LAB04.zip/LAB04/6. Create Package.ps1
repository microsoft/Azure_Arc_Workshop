  $ProgressPreference = 'SilentlyContinue'  
  $params = @{
    Name          = 'AzureArcLevelUp_Windows'
    Configuration = "$OutputPath/localhost.mof"
    Type          = 'AuditAndSet'
    Path          = $OutputPath
    Force         = $true
        }
  New-GuestConfigurationPackage @params