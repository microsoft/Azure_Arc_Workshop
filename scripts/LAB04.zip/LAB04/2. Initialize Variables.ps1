$resourceGroupName = "ArcBox"
$location = $env:azureLocation
$Win2k25vmName = "ArcBox-Win2K25"
$Win2k22vmName = "ArcBox-Win2K22"

# Disconnect from Managed Identity as we need subscription-level permissions to create Azure Policy definitions
Clear-AzContext -Force

# Connect using your own account
Connect-AzAccount -Tenant $env:spnTenantId -UseDeviceAuthentication