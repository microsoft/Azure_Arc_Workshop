  $PolicyId = (New-Guid).Guid

  New-GuestConfigurationPolicy `
    -PolicyId $PolicyId `
    -ContentUri $ContentUri `
    -DisplayName '(AzureArcJumpstart) [Windows] Custom configuration' `
    -Description 'Azure Arc Jumpstart Windows demo configuration' `
    -Path  $OutputPath `
    -Platform 'Windows' `
    -PolicyVersion 1.0.0 `
    -Mode ApplyAndAutoCorrect `
    -Verbose -OutVariable Policy

    $PolicyParameterObject = @{'IncludeArcMachines'='true'}

    New-AzPolicyDefinition -Name '(AzureArcJumpstart) [Windows] Custom configuration' -Policy $Policy.Path -OutVariable PolicyDefinition