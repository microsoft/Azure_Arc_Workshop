  Import-Module PSDesiredStateConfiguration -RequiredVersion 2.0.7

  $PS7Url = "https://github.com/PowerShell/PowerShell/releases/latest"
  $PS7LatestVersion = (Invoke-WebRequest -Uri $PS7url).Content | Select-String -Pattern "[0-9]+\.[0-9]+\.[0-9]+" | Select-Object -ExpandProperty Matches | Select-Object -ExpandProperty Value
  $PS7DownloadUrl = "https://github.com/PowerShell/PowerShell/releases/download/v$PS7LatestVersion/PowerShell-$PS7LatestVersion-win-x64.msi"
  Invoke-WebRequest -Uri $PS7DownloadUrl -OutFile $env:TEMP\ps.msi
  $PS7ProductId = (Get-MSIProperty -Path $env:TEMP\ps.msi -Property ProductCode).Value

  Configuration AzureArcLevelUp_Windows
  {
      param (
          [Parameter(Mandatory)]
          [System.Management.Automation.PSCredential]
          [System.Management.Automation.Credential()]
          $PasswordCredential
      )

      Import-DscResource -ModuleName 'PSDscResources' -ModuleVersion 2.12.0.0

      Node localhost
      {
          MsiPackage PS7
          {
              ProductId = $PS7ProductId
              Path = $PS7DownloadUrl
              Ensure = 'Present'
          }
          User ArcBoxUser
          {
              UserName = 'arcboxuser1'
              FullName = 'ArcBox User 1'
              Password = $PasswordCredential
              Ensure = 'Present'
          }
          WindowsFeature SMB1 {
              Name = 'FS-SMB1'
              Ensure = 'Absent'
          }
      }
  }
  Write-Host "Creating credentials for arcbox user 1"
  $nestedWindowsUsername = "arcboxuser1"
  $nestedWindowsPassword = "<Insert password before running>"  # In real-world scenarios this could be retrieved from an Azure Key Vault

  # Create Windows credential object
  $secWindowsPassword = ConvertTo-SecureString $nestedWindowsPassword -AsPlainText -Force
  $winCreds = New-Object System.Management.Automation.PSCredential ($nestedWindowsUsername, $secWindowsPassword)

  $ConfigurationData = @{
      AllNodes = @(
          @{
              NodeName = 'localhost'
              PSDscAllowPlainTextPassword = $true
          }
      )
  }
  $OutputPath = "$Env:ArcBoxDir/arc_automanage_machine_configuration_custom_windows"
  New-Item $OutputPath -Force -ItemType Directory | Out-Null