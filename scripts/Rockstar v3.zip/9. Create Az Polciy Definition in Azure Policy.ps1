## Create Az Polciy Definition in Azure Policy
New-AzPolicyDefinition -Name '(ArcBox) Account Login Policy Settings' -Policy C:\Rockstar\AccountPolicy_config\policies\AccountPolicy_config_DeployIfNotExists.json
