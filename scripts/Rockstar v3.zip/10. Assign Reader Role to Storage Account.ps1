# Assign role 
# Variables
$arcMachineName    = "ArcBox-Win2K25"
$roleName          = "Storage Blob Data Reader"
$storageaccountScope = $storageaccount.StorageAccountName
$arcMachine = Get-AzConnectedMachine -ResourceGroupName $resourceGroupName -Name $arcMachineName
$principalId = $arcMachine.IdentityPrincipalId
Write-Host "PrincipalId: $principalId"

# Scope for the storage account
$scope = "/subscriptions/$subscriptionId/resourceGroups/$resourceGroupName/providers/Microsoft.Storage/storageAccounts/$storageaccountScope"

# Assign role
New-AzRoleAssignment `
    -ObjectId $principalId `
    -RoleDefinitionName $roleName `
    -Scope $scope