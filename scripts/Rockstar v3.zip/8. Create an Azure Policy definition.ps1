
$bracher_guid = New-Guid

$PolicyConfig4      = @{
  PolicyId                  = $bracher_guid
  ContentUri                = $contentUri
  DisplayName               = '(ArcBox) Account Login Policy Settings'
  Description               = '(ArcBox) Account Login Policy Settings'
  Path                      = 'AccountPolicy_config/policies'
  Platform                  = 'Windows'
  PolicyVersion             = '1.0.0'
  Mode                      = 'ApplyAndAutoCorrect'
  LocalContentPath          = "C:\Rockstar\AccountPolicy_config.zip"      # Required parameter for managed identity
}
New-GuestConfigurationPolicy @PolicyConfig4 -UseSystemAssignedIdentity